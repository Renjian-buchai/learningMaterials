#ifndef LVERTEX_2D_H
#define LVERTEX_2D_H

#include "LOpenGL.h"

struct LVertex2D
{
    GLfloat x;
    GLfloat y;
};

#endif
