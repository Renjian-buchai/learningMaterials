Copyright Notice:
-----------------
The files within this zip file are copyrighted by Lazy Foo' Productions (2004-2013)
and may not be redistributed without written permission.

This project is linked against:
----------------------------------------
Windows:
OpenGL32
freeglut
Devil
ilu

*nix:
GL
freeglut
Devil
ilu
